/* ============================================================
   BAKERSS — SHARED COMPONENTS (Header, Footer, Sticky CTA)
   ============================================================ */

function getTopBar() {
  return `
  <div class="topbar" role="banner">
    <div class="container">
      <span>🌴 Serving All of Horry County, SC — Residential &amp; Commercial</span>
      <div class="topbar-right">
        <a href="tel:8434677136">📞 (843) 467-7136</a>
        <a href="mailto:cloyd.raymond@yahoo.com">✉ cloyd.raymond@yahoo.com</a>
      </div>
    </div>
  </div>`;
}

function getHeader() {
  return `
  <header class="site-header" role="navigation" aria-label="Main navigation">
    <nav class="nav-inner">
      <a href="/" class="nav-logo" aria-label="Bakerss Property Maintenance Home">
        <img src="/images/logo.png" alt="Bakerss Property Maintenance Logo" width="160" height="60" style="height:56px;width:auto;display:block;">
      </a>
      <ul class="nav-menu" role="menubar">
        <li role="none"><a href="/" role="menuitem">Home</a></li>
        <li class="nav-dropdown" role="none">
          <a href="/services/" role="menuitem">Services</a>
          <ul class="dropdown-menu" role="menu" aria-label="Services submenu">
            <li class="dropdown-section-label">Outdoor</li>
            <li><a href="/services/lawn-care/" role="menuitem">🌿 Lawn Care &amp; Landscaping</a></li>
            <li><a href="/services/pressure-washing/" role="menuitem">💧 Pressure Washing</a></li>
            <li><a href="/services/gutter-cleaning/" role="menuitem">🏠 Gutter Cleaning</a></li>
            <li><a href="/services/exterior-painting/" role="menuitem">🎨 Exterior Painting</a></li>
            <li><a href="/services/exterior-lighting/" role="menuitem">💡 Exterior Lighting</a></li>
            <div class="dropdown-divider"></div>
            <li class="dropdown-section-label">Interior</li>
            <li><a href="/services/interior-cleaning/" role="menuitem">✨ Interior Cleaning</a></li>
            <li><a href="/services/interior-painting/" role="menuitem">🖌 Interior Painting</a></li>
            <li><a href="/services/plumbing/" role="menuitem">🔧 Minor Plumbing</a></li>
            <li><a href="/services/electrical/" role="menuitem">⚡ Minor Electrical</a></li>
            <div class="dropdown-divider"></div>
            <li class="dropdown-section-label">Specialty</li>
            <li><a href="/services/deck-building/" role="menuitem">🪵 Deck Building</a></li>
            <li><a href="/services/epoxy-flooring/" role="menuitem">🏗 Epoxy Flooring</a></li>
            <li><a href="/services/drywall/" role="menuitem">🔨 Drywall</a></li>
            <li><a href="/services/handyman/" role="menuitem">🛠 Handyman Services</a></li>
            <li><a href="/services/property-packages/" role="menuitem">📦 Property Packages</a></li>
          </ul>
        </li>
        <li class="nav-dropdown" role="none">
          <a href="/service-areas/" role="menuitem">Service Areas</a>
          <ul class="dropdown-menu" role="menu" aria-label="Service areas submenu">
            <li><a href="/service-areas/horry-county/" role="menuitem">🗺 All of Horry County</a></li>
            <div class="dropdown-divider"></div>
            <li><a href="/myrtle-beach/" role="menuitem">Myrtle Beach</a></li>
            <li><a href="/murrells-inlet/" role="menuitem">Murrells Inlet</a></li>
            <li><a href="/conway/" role="menuitem">Conway</a></li>
            <li><a href="/surfside-beach/" role="menuitem">Surfside Beach</a></li>
            <li><a href="/garden-city/" role="menuitem">Garden City</a></li>
            <li><a href="/north-myrtle-beach/" role="menuitem">North Myrtle Beach</a></li>
            <li><a href="/socastee/" role="menuitem">Socastee</a></li>
          </ul>
        </li>
        <li role="none"><a href="/learning-center/" role="menuitem">Learning Center</a></li>
        <li role="none"><a href="/reviews/" role="menuitem">Reviews</a></li>
        <li role="none"><a href="/about/" role="menuitem">About</a></li>
        <li role="none"><a href="/contact/" role="menuitem">Contact</a></li>
      </ul>
      <div class="nav-cta">
        <a href="tel:8434677136" class="btn btn-primary btn-sm">📞 (843) 467-7136</a>
      </div>
      <button class="nav-toggle" aria-label="Toggle mobile menu" aria-expanded="false" aria-controls="nav-menu">
        <span></span><span></span><span></span>
      </button>
    </nav>
  </header>`;
}

function getStickyCTA() {
  return `
  <div class="sticky-cta" role="complementary" aria-label="Quick contact options">
    <a href="tel:8434677136" class="sticky-cta-btn primary">
      <span class="icon">📞</span>
      <span>Call Now</span>
    </a>
    <a href="sms:8434677136" class="sticky-cta-btn">
      <span class="icon">💬</span>
      <span>Text Us</span>
    </a>
    <a href="/contact/" class="sticky-cta-btn">
      <span class="icon">📅</span>
      <span>Free Estimate</span>
    </a>
  </div>`;
}

function getFooter() {
  return `
  <footer class="site-footer" role="contentinfo">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="logo"><img src="/images/logo.png" alt="Bakerss Property Maintenance" style="height:60px;width:auto;filter:brightness(0) invert(1);margin-bottom:12px;"></div>
        <p>Myrtle Beach's trusted property maintenance company. We take care of your property so you can enjoy life. Serving all of Horry County, SC — residential &amp; commercial.</p>
        <div class="footer-contact-item">
          <span class="icon">📞</span>
          <a href="tel:8434677136">(843) 467-7136 — Call or Text Anytime</a>
        </div>
        <div class="footer-contact-item">
          <span class="icon">✉</span>
          <a href="mailto:cloyd.raymond@yahoo.com">cloyd.raymond@yahoo.com</a>
        </div>
        <div class="footer-contact-item">
          <span class="icon">🕐</span>
          <span>Available 24/7 — We answer every call</span>
        </div>
      </div>
      <div class="footer-col">
        <h4>Our Services</h4>
        <ul>
          <li><a href="/services/lawn-care/">Lawn Care &amp; Landscaping</a></li>
          <li><a href="/services/interior-cleaning/">Interior Cleaning</a></li>
          <li><a href="/services/pressure-washing/">Pressure Washing</a></li>
          <li><a href="/services/painting/">Painting</a></li>
          <li><a href="/services/gutter-cleaning/">Gutter Cleaning</a></li>
          <li><a href="/services/deck-building/">Deck Building</a></li>
          <li><a href="/services/handyman/">Handyman Services</a></li>
          <li><a href="/services/epoxy-flooring/">Epoxy Flooring</a></li>
          <li><a href="/services/property-packages/">Property Packages</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Service Areas</h4>
        <ul>
          <li><a href="/myrtle-beach/">Myrtle Beach</a></li>
          <li><a href="/murrells-inlet/">Murrells Inlet</a></li>
          <li><a href="/conway/">Conway</a></li>
          <li><a href="/surfside-beach/">Surfside Beach</a></li>
          <li><a href="/garden-city/">Garden City</a></li>
          <li><a href="/north-myrtle-beach/">North Myrtle Beach</a></li>
          <li><a href="/socastee/">Socastee</a></li>
          <li><a href="/service-areas/horry-county/">All Horry County</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="/about/">About Bakerss</a></li>
          <li><a href="/reviews/">Customer Reviews</a></li>
          <li><a href="/learning-center/">Learning Center</a></li>
          <li><a href="/contact/">Free Estimate</a></li>
          <li><a href="/contact/">Contact Us</a></li>
          <li><a href="/sitemap.xml">Sitemap</a></li>
        </ul>
        <div style="margin-top:24px;">
          <p style="font-size:0.78rem;color:rgba(255,255,255,0.4);margin-bottom:8px;">STARTING PRICES</p>
          <p style="font-size:0.82rem;color:rgba(255,255,255,0.6);margin:0;">🌿 Lawn Care from $50</p>
          <p style="font-size:0.82rem;color:rgba(255,255,255,0.6);margin:4px 0 0;">💧 Pressure Wash from $125</p>
          <p style="font-size:0.82rem;color:rgba(255,255,255,0.6);margin:4px 0 0;">✨ House Cleaning from $100</p>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2025 Bakerss Property Maintenance. All rights reserved. Serving Horry County, SC.</span>
      <span><a href="/privacy/">Privacy Policy</a> · <a href="/sitemap.xml">Sitemap</a></span>
    </div>
  </footer>`;
}

// Auto-inject if elements exist
document.addEventListener('DOMContentLoaded', function() {
  const topbarSlot = document.getElementById('topbar-slot');
  const headerSlot = document.getElementById('header-slot');
  const footerSlot = document.getElementById('footer-slot');
  const ctaSlot   = document.getElementById('sticky-cta-slot');
  if (topbarSlot) topbarSlot.outerHTML = getTopBar();
  if (headerSlot) headerSlot.outerHTML = getHeader();
  if (footerSlot) footerSlot.outerHTML = getFooter();
  if (ctaSlot)    ctaSlot.outerHTML   = getStickyCTA();
});
