/* ============================================================
   BAKERSS PROPERTY MAINTENANCE — MAIN JS
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

  /* ── MOBILE NAV TOGGLE ─────────────────────────────────── */
  const navToggle = document.querySelector('.nav-toggle');
  const siteHeader = document.querySelector('.site-header');
  if (navToggle && siteHeader) {
    navToggle.addEventListener('click', function () {
      siteHeader.classList.toggle('nav-open');
      const expanded = siteHeader.classList.contains('nav-open');
      navToggle.setAttribute('aria-expanded', expanded);
      // Animate hamburger
      const spans = navToggle.querySelectorAll('span');
      if (expanded) {
        spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
        spans[1].style.opacity = '0';
        spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
      } else {
        spans[0].style.transform = '';
        spans[1].style.opacity = '';
        spans[2].style.transform = '';
      }
    });
    // Close nav on outside click
    document.addEventListener('click', function (e) {
      if (siteHeader.classList.contains('nav-open') && !siteHeader.contains(e.target)) {
        siteHeader.classList.remove('nav-open');
      }
    });
  }

  /* ── FAQ ACCORDION ─────────────────────────────────────── */
  document.querySelectorAll('.faq-question').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const item = this.closest('.faq-item');
      const isOpen = item.classList.contains('open');
      // Close all
      document.querySelectorAll('.faq-item.open').forEach(function (i) {
        i.classList.remove('open');
      });
      // Toggle current
      if (!isOpen) {
        item.classList.add('open');
      }
    });
  });

  /* ── CONTACT FORM ──────────────────────────────────────── */
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const formData = new FormData(this);
      const data = Object.fromEntries(formData.entries());

      // Build mailto
      const subject = encodeURIComponent('New Estimate Request — Bakerss Property Maintenance');
      const body = encodeURIComponent(
        'Name: ' + (data.name || '') + '\n' +
        'Phone: ' + (data.phone || '') + '\n' +
        'Email: ' + (data.email || '') + '\n' +
        'Service: ' + (data.service || '') + '\n' +
        'City: ' + (data.city || '') + '\n\n' +
        'Message:\n' + (data.message || '')
      );

      window.location.href = 'mailto:cloyd.raymond@yahoo.com?subject=' + subject + '&body=' + body;

      const success = document.getElementById('form-success');
      if (success) {
        success.style.display = 'block';
        contactForm.reset();
        setTimeout(function () { success.style.display = 'none'; }, 6000);
      }
    });
  }

  /* ── SMOOTH SCROLL FOR ANCHOR LINKS ───────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* ── INTERSECTION OBSERVER FOR ANIMATIONS ─────────────── */
  const animEls = document.querySelectorAll('.service-card, .review-card, .step-card, .article-card, .location-card, .stat-item');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    animEls.forEach(function (el) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(16px)';
      el.style.transition = 'opacity 0.45s ease, transform 0.45s ease';
      observer.observe(el);
    });
  }

  /* ── STAT COUNTER ANIMATION ───────────────────────────── */
  function animateCounter(el) {
    const target = parseInt(el.getAttribute('data-target') || el.textContent, 10);
    const suffix = el.getAttribute('data-suffix') || '';
    if (isNaN(target)) return;
    let current = 0;
    const increment = Math.ceil(target / 60);
    const timer = setInterval(function () {
      current += increment;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      el.textContent = current.toLocaleString() + suffix;
    }, 25);
  }

  const statNumbers = document.querySelectorAll('.stat-number[data-target]');
  if (statNumbers.length && 'IntersectionObserver' in window) {
    const statObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          statObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    statNumbers.forEach(function (el) { statObserver.observe(el); });
  }

  /* ── ACTIVE NAV LINK ──────────────────────────────────── */
  const currentPath = window.location.pathname.replace(/\/$/, '') || '/';
  document.querySelectorAll('.nav-menu a').forEach(function (link) {
    const linkPath = link.getAttribute('href').replace(/\/$/, '') || '/';
    if (currentPath === linkPath || (linkPath !== '/' && currentPath.startsWith(linkPath))) {
      link.classList.add('active');
    }
  });

});
